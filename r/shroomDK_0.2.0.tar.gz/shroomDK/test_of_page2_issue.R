query <- "SELECT seller_address, buyer_address, project_name FROM ETHEREUM.CORE.ez_nft_sales LIMIT 5001"

api_key = readLines("api_key.txt")
qt <- create_query_token(query, api_key)

qs <- get_query_status(qt$result$queryRequest$queryRunId, api_key)
df = list()
for(i in 1:6){
  df[[i]] <- get_query_from_token(query_run_id = qt$result$queryRequest$queryRunId,
                                  api_key = api_key,
                                  page_number = i,
                                  page_size = 1000)
}

# something breaks
dfclean <- lapply(df[1:6], clean_query)
dfc <- do.call(rbind, dfclean)

lapply(df, function(x){
  summary(as.numeric(clean_query(x, try_simplify = FALSE)[["__row_index"]]))
})
